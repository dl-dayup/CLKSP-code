任务一数据结构：
任务一数据每一行为一个json
json key 为['originalText','entities'] 即原文和实体列表
json["entities"]为列表，每个元素代表一个实体entity，其中有该实体在原文中的起始位置start_pos,结束位置end_pos,以及实体类型
